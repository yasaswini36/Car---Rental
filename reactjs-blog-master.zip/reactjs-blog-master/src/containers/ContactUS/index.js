import React from 'react'

/**
* @author
* @function ContactUS
**/

const ContactUS = (props) => {
  return(
    <div>ContactUS</div>
   )

 }

export default ContactUS